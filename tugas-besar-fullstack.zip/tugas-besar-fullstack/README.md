# Tugas Besar - Platform Figur Populer (Full-Stack)

Platform web untuk mengelola data tokoh/figur populer dengan penyimpanan gambar mandiri (MinIO) dan integrasi AI kampus (Ollama).

## Stack
- **Database**: MongoDB
- **Backend**: Express.js + Swagger
- **Frontend**: Next.js (App Router) + Tailwind
- **Object Storage**: MinIO (S3-compatible)
- **AI**: Ollama kampus (`https://ollama.if.unismuh.ac.id/api/generate`)
- **Container**: Docker Compose, dikembangkan di GitHub Codespaces

## Struktur Folder
```
tugas-besar-fullstack/
├── backend/            # Express.js API
│   └── src/
│       ├── config/     # koneksi MongoDB & MinIO
│       ├── models/     # Mongoose schema
│       ├── controllers/
│       ├── routes/     # + dokumentasi Swagger
│       └── swagger/
├── frontend/           # Next.js App Router
│   ├── app/
│   ├── components/
│   └── lib/            # axios API client
├── .devcontainer/       # config GitHub Codespaces
└── docker-compose.yml
```

## Cara Menjalankan (di GitHub Codespaces atau lokal)

1. **Siapkan file environment**
   ```bash
   cp backend/.env.example backend/.env
   cp frontend/.env.example frontend/.env
   ```

2. **Jalankan semua service**
   ```bash
   docker-compose up --build
   ```

3. **Akses aplikasi**
   | Service            | URL                                      |
   |---------------------|-------------------------------------------|
   | Frontend            | http://localhost:3000                    |
   | Backend API          | http://localhost:5000/api/figures        |
   | Swagger Docs         | http://localhost:5000/api-docs           |
   | MinIO Console        | http://localhost:9001 (minioadmin / minioadmin123) |

   > Di GitHub Codespaces, gunakan tab **PORTS** untuk membuka URL publik masing-masing port (klik kanan → "Port Visibility" → **Public** kalau perlu diakses browser luar).

4. **Tambah data pertama kali**
   Karena database masih kosong, gunakan Swagger UI (`/api-docs`) untuk `POST /api/figures` menambahkan data figur pertama, baru upload gambarnya lewat endpoint upload-image atau langsung di halaman detail frontend.

## Endpoint Utama

| Method | Endpoint                              | Keterangan                          |
|--------|-----------------------------------------|--------------------------------------|
| GET    | `/api/figures?search=&category=`        | List + search/filter figur           |
| GET    | `/api/figures/:id`                      | Detail figur                         |
| POST   | `/api/figures`                          | Tambah figur                         |
| PUT    | `/api/figures/:id`                      | Update figur                         |
| DELETE | `/api/figures/:id`                      | Hapus figur                          |
| POST   | `/api/figures/:id/upload-image`         | Upload foto profil ke MinIO          |
| POST   | `/api/ai/generate`                      | Tanya-jawab bebas ke Ollama          |
| POST   | `/api/ai/summarize/:figureId`           | Ringkas bio figur pakai AI           |

## Catatan Penting
- Endpoint Ollama kampus (`ollama.if.unismuh.ac.id`) biasanya hanya bisa diakses dari **jaringan kampus atau VPN kampus**. Kalau di Codespaces muncul error timeout/connection refused di `/api/ai/generate`, itu kemungkinan besar karena Codespaces berjalan di server luar jaringan kampus — bukan bug di kode. Solusinya: uji dari jaringan kampus, atau tanyakan dosen apakah endpoint bisa diakses publik/perlu API key tertentu.
- `MINIO_PUBLIC_HOST` di `.env` backend perlu disesuaikan kalau frontend diakses dari domain Codespaces (bukan localhost), supaya URL gambar tetap bisa diakses browser.

## Tahap Selanjutnya
1. ✅ Setup struktur folder & docker-compose (selesai)
2. ✅ Skema database & CRUD backend (selesai - contoh model `Figure`)
3. ✅ Integrasi MinIO upload gambar (selesai)
4. ✅ Integrasi endpoint Ollama AI (selesai)
5. ⬜ Frontend styling & UX lanjutan (search debounce sudah ada, bisa ditambah pagination UI, loading skeleton, dsb.)
6. ⬜ Autentikasi/otorisasi kalau dosen mensyaratkan (belum diimplementasikan)
7. ⬜ Testing endpoint & deployment

Kalau ada bagian yang error atau mau dikembangkan lagi (misalnya nambah pagination di UI, autentikasi, atau relasi antar figur), tinggal bilang saja bagian mana yang dikerjakan.
